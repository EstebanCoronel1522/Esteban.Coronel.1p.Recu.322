
package ParcialRecuperatorio;

public enum TipoAnalisis {
  DESCRIPTIVO,
  INFERENCIAL,
  PREDICTIVO;
}
