
package ParcialRecuperatorio;


public interface Actualizable {
    void actualizarResultados();
}
