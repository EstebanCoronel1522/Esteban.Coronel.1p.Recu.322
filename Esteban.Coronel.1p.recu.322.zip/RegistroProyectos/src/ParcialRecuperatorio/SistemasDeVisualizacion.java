package ParcialRecuperatorio;

public class SistemasDeVisualizacion extends Proyecto{
   
    private int cantidadGraficosGenerados;
    public SistemasDeVisualizacion(int cantidadGraficosGenerados, String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
        super(nombre, equipoResponsable, estadoActual);
        this.cantidadGraficosGenerados = cantidadGraficosGenerados;
    }
    
    
      public int getCantidadGraficosGenerados() {
        return cantidadGraficosGenerados;
      }
        @Override
    public String toString() {
        return "\nSistemasDeVisualizacion{"+ super.toString() + "cantidadGraficosGenerados=" + cantidadGraficosGenerados + '}';
    }  
}
