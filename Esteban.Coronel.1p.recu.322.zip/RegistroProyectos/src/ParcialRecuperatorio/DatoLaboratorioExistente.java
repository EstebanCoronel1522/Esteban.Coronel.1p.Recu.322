package ParcialRecuperatorio;


public class DatoLaboratorioExistente extends Exception{
    private static final String MESSAGE = " ";
    
    public DatoLaboratorioExistente(){
        this(MESSAGE);
        
    }
    public DatoLaboratorioExistente (String mensaje){
        super(mensaje);
    }
}

    

