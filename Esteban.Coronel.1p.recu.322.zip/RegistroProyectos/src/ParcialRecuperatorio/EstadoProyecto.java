package ParcialRecuperatorio;


public enum EstadoProyecto {
    EN_DESARROLLO,
    ENTRENANDO_MODELO,
    FINALIZADO;
}
