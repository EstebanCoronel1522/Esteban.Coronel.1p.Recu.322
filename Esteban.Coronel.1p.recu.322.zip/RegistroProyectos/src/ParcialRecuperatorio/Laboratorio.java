
package ParcialRecuperatorio;

import java.util.ArrayList;


public class Laboratorio {
    private ArrayList<Proyecto> listaProyecto = new ArrayList<>();
    
    public void agregarProyecto(Proyecto proyecto)throws DatoLaboratorioExistente{
        if (proyecto == null)
            throw new IllegalArgumentException ("Proyecto nulo ");
        
        if (listaProyecto.contains(proyecto)){
        throw new DatoLaboratorioExistente ("Ya existe este proyecto " + proyecto.getNombre()
                    + " en el laboratorio " + proyecto.getEquipoResponsable());
        }
        listaProyecto.add(proyecto);
        System.out.println("Proyecto " + proyecto.getNombre() + " agregado ") ;
    }
    
    public void mostrarProyectos(){
        if (listaProyecto.isEmpty()){
            System.out.println("No se encuentran proyectos registrados ");
        }else{
        for (Proyecto proyecto : listaProyecto){
            System.out.println(proyecto.toString());
    }
        
  }
 }
    public void actualizarResultadosProyectos(){
        for (Proyecto proyecto: listaProyecto){
            if( proyecto instanceof SistemasDeVisualizacion){
                System.out.println("Visualizacion no puede actualizarse directamente ");
                continue;
            }
            
           ((Actualizable)proyecto).actualizarResultados();
        }
    }
    public ArrayList<Proyecto> actualizarEstadoProyectos(EstadoProyecto nuevoEstado) {
    ArrayList<Proyecto> listaActualizada = new ArrayList<>();

    if (nuevoEstado == null) {
        System.out.println("No se realizó ninguna modificación (el estado indicado es nulo). ");
        return listaActualizada;
    }

    for (Proyecto proyecto : listaProyecto) {
        EstadoProyecto estadoAnterior = proyecto.getEstadoActual();

        if (!estadoAnterior.equals(nuevoEstado)) {
            proyecto.setEstadoActual(nuevoEstado);
            listaActualizada.add(proyecto);
            System.out.println(proyecto.getNombre() + " actualizado de " + estadoAnterior + " a " + nuevoEstado);
        }
    }

    if (listaActualizada.isEmpty()) {
        System.out.println("No había proyectos con estado distinto al indicado. ");
        }

    return listaActualizada;
    }
}
