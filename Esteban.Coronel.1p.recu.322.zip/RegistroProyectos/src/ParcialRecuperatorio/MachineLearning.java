package ParcialRecuperatorio;

public class MachineLearning extends Proyecto implements Actualizable {

           private double porcentajePrecisionAlcanzado;
           private static final double PORC_MAX = 100;
           private static final double PORC_MIN = 0;
           public MachineLearning(double porcentajePrecisionAlcanzado, String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
           super(nombre, equipoResponsable, estadoActual);
           this.porcentajePrecisionAlcanzado = porcentajePrecisionAlcanzado;
           if (porcentajePrecisionAlcanzado > PORC_MAX || porcentajePrecisionAlcanzado< PORC_MIN){
               throw new IllegalArgumentException (getNombre()+": " + "Porcentaje fuera de rango");
           }
    
    }        
        public double getPorcentajePrecisionAlcanzado() {
            return porcentajePrecisionAlcanzado;
        }

        @Override
        public void actualizarResultados(){
            System.out.println("El proyecto: " + this.getNombre() + "fue actualizado ");
}

    @Override
    public String toString() {
        
        return  "\nMachineLearning{" + super.toString() + "porcentajePrecisionAlcanzado=" + porcentajePrecisionAlcanzado + '}';
    }
}
        


