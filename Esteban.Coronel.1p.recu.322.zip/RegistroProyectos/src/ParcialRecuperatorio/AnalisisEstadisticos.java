
package ParcialRecuperatorio;

public class AnalisisEstadisticos extends Proyecto implements Actualizable {

   
    private TipoAnalisis tipoAnalisis;
    public AnalisisEstadisticos(TipoAnalisis tipoAnalisis, String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
        super(nombre, equipoResponsable, estadoActual);
        this.tipoAnalisis = tipoAnalisis;
    }
    
    
     public TipoAnalisis getTipoAnalisis() {
        return tipoAnalisis;
    }
    @Override
    public void actualizarResultados(){
        System.out.println("El proyecto: " + getNombre()+ this.getNombre() + " fue actualizado" );
    }
    @Override
    public String toString() {
        return "\nAnalisisEstadisticos{"+ super.toString() + "tipoAnalisis=" + tipoAnalisis + '}';
    }
  
}
