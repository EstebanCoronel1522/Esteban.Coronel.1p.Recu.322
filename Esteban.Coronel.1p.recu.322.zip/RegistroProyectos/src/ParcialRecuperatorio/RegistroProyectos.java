package ParcialRecuperatorio;

public class RegistroProyectos {

public static void main(String[] args) throws DatoLaboratorioExistente {

        Laboratorio sistema = new Laboratorio();

        System.out.println("--- Agregando Proyectos ---");

        try {
            sistema.agregarProyecto(new MachineLearning(8.5, "Prediccion de Ventas", "DataScienceTeam", EstadoProyecto.EN_DESARROLLO));
            sistema.agregarProyecto(new MachineLearning(8.5, "Prediccion de Ventas", "DataScienceTeam", EstadoProyecto.EN_DESARROLLO));
        } catch (DatoLaboratorioExistente e) {
            System.out.println(e.getMessage());
        }

        try {
            sistema.agregarProyecto(new MachineLearning(90.5, "Clasificacion de Imagenes", "QATeam", EstadoProyecto.ENTRENANDO_MODELO));
            sistema.agregarProyecto(new MachineLearning(101, "Clasificacion de Datos ", "DataCenter", EstadoProyecto.ENTRENANDO_MODELO));
            sistema.agregarProyecto(new MachineLearning(90.5, "Clasificacion de Imagenes", "QATeam", EstadoProyecto.ENTRENANDO_MODELO));
        } catch (DatoLaboratorioExistente | IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
        sistema.agregarProyecto(new AnalisisEstadisticos(TipoAnalisis.PREDICTIVO, "Analisis de Comportamiento", "AnalyticsTeam", EstadoProyecto.EN_DESARROLLO));
        sistema.agregarProyecto(new AnalisisEstadisticos(TipoAnalisis.INFERENCIAL, "Correlaciones de Variables", "BioLab", EstadoProyecto.EN_DESARROLLO));
        sistema.agregarProyecto(new SistemasDeVisualizacion(6, "Visualizacion de Datos de Trafico", "DataVizGroup", EstadoProyecto.EN_DESARROLLO));

        System.out.println("\n--- Proyectos Registrados ---");
        sistema.mostrarProyectos();

        System.out.println("\n--- Actualizando Resultados ---");
        sistema.actualizarResultadosProyectos();

        System.out.println("\n--- Actualizando Estado de Proyectos a FINALIZADO ---");
        sistema.actualizarEstadoProyectos(EstadoProyecto.FINALIZADO);

        System.out.println("\n--- Estado Final de los Proyectos ---");
        sistema.mostrarProyectos();
    }
}
    

