
package ParcialRecuperatorio;

import java.util.Objects;


public abstract class Proyecto {
   
    private String nombre;
    private String equipoResponsable;
    private EstadoProyecto estadoActual;

    public Proyecto(String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
        this.nombre = nombre;
        this.equipoResponsable = equipoResponsable;
        this.estadoActual = estadoActual;
    }
       public String getNombre() {
        return nombre;
    }

    public String getEquipoResponsable() {
        return equipoResponsable;
    }

    public EstadoProyecto getEstadoActual() {
        return estadoActual;
   
    }

    public void setEstadoActual(EstadoProyecto estadoActual) {
        this.estadoActual = estadoActual;
    }
        @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Proyecto)) return false;
        Proyecto proyecto = (Proyecto) o;
        return nombre.equals(proyecto.nombre) &&
               equipoResponsable.equals(proyecto.equipoResponsable);
    } 
    protected String muestra(){
        StringBuilder sb= new StringBuilder();
        sb.append ("\nNombre proyecto: " + this.getNombre() + " ");
        sb.append ("\nEstado actual: " + this.getEstadoActual() + " ");
        sb.append ("\nEquipoResponsable: " + this.getEquipoResponsable() + " ");
        return(sb.toString());
    }
    @Override
    public String toString(){
        return this.muestra();
    }
}
